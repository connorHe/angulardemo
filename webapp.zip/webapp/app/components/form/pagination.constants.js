(function() {
    'use strict';

    angular
        .module('testjhipsterApp')
        .constant('paginationConstants', {
            'itemsPerPage': 20
        });
})();
